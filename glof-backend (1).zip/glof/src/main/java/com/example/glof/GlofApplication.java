package com.example.glof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlofApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlofApplication.class, args);
	}

}
