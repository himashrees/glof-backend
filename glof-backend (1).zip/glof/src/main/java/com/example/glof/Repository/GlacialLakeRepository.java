package com.example.glof.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.glof.Model.GlacialLake;

import com.example.glof.Model.GlacialLake;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GlacialLakeRepository extends JpaRepository<GlacialLake, Long> {
    // Custom query for retrieving lakes within a region (optional)
    List<GlacialLake> findByLatitudeBetweenAndLongitudeBetween(double latStart, double latEnd, double lonStart, double lonEnd);
}
