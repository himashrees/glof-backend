package com.example.glof.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.glof.Model.Alert;
import com.example.glof.Model.GlacialLake;
import com.example.glof.Repository.AlertRepository;

@Service
public class AlertService {

    @Autowired
    private AlertRepository alertRepository;

    public List<Alert> getAlertsByLake(Long lakeId) {
        return alertRepository.findByLakeId(lakeId);
    }

    public void createAlert(GlacialLake lake, String type, String severity, String message) {
        Alert alert = new Alert();
        alert.setLake(lake);
        alert.setType(type);
        alert.setSeverity(severity);
        alert.setMessage(message);
        alert.setTimestamp(LocalDateTime.now());
        alertRepository.save(alert);
    }
}

