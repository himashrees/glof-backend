package com.example.glof.Service;



import com.example.glof.Model.User;
import com.example.glof.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public String signup(User user) {
        // Check if username already exists
        if (userRepository.findByUsername(user.getUsername()) != null) {
            return "Username already exists!";
        }

        // Store the user (In real scenarios, hash the password using BCrypt or similar)
        userRepository.save(user);
        return "User registered successfully!";
    }

    public String login(String username, String password) {
        User user = userRepository.findByUsername(username);

        if (user == null || !user.getPassword().equals(password)) {
            return "Invalid username or password!";
        }

        return "Login successful!";
    }
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Find user by ID
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }
}


